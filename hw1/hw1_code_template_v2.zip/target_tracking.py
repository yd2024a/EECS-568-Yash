import numpy as np


def target_tracking():
    # known parameters
    mu0 = 20
    sigma0_square = 9
    F = 1
    Q = 4
    H = 1
    R = 1
    z1 = 22
    z2 = 23

    mu2 = 0
    sigma2_square = 0

    #############################################################################
    #                    TODO: Implement your code here                         #
    #############################################################################

    # prediction step (1st iteration)
    # mu1_hat = ...
    # sigma1_square_hat = ...

    # correction step (1st iteration)
    # K1 = ...
    # mu1 = ...
    # sigma1_square = ...

    # prediction step (2nd iteration)
    # mu2_hat = ...
    # sigma2_square_hat = ...

    # correction step (2nd iteration)
    # K2 = ...
    # mu2 = ...
    # sigma2_square = ...

    #############################################################################
    #                            END OF YOUR CODE                               #
    #############################################################################

    return (mu2, sigma2_square)


if __name__ == '__main__':
    # Test your funtions here

    print('Answer for Problem 3:\n', target_tracking())
