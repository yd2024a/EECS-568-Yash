import setuptools

setuptools.setup(
    name="minslam",
    version="0.0.1",
    description="A minimal SLAM system",
    packages=setuptools.find_packages(),
    python_requires='>=3.7'
)
